package com.example.demo.game;

public class SuperMario implements GamingConsole {

	public void up(){
		System.out.println("UP from SuperMario");
	}
	
	public void down() {
		System.out.println("DOWN from SuperMario");	
	}
	
	public void left(){
		System.out.println("LEFT from SuperMario");
	}
	
	public void right(){
		System.out.println("RIGHT from SuperMario");
	}

}
