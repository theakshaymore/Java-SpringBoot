package com.example.demo.game;

public class Mario implements GamingConsole {
	
	public void up(){
		System.out.println("UP from Mario");
	}
	
	public void down() {
		System.out.println("DOWN from Mario");	
	}
	
	public void left(){
		System.out.println("LEFT from Mario");
	}
	
	public void right(){
		System.out.println("RIGHT from Mario");
	}

}
