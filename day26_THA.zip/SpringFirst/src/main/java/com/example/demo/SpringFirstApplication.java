package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.example.demo.game.GameRunner;

@SpringBootApplication
public class SpringFirstApplication {

	public static void main(String[] args) {
		//SpringApplication.run(SpringFirstApplication.class, args);
		System.out.println("Hello Spring");
		
		GameRunner gameRunner = new GameRunner();
		gameRunner.run();
	}

}
