package com.example.demo.persistance;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Student;

@Repository
public class Student_Implementations implements Student_Declarations
{
	private EntityManager entitymgr;
	
	@Autowired
    public Student_Implementations(EntityManager entitymgr) 
	{
	this.entitymgr = entitymgr;
    }
	
	@Override
	public List<Student> displayAll() {
		// TODO Auto-generated method stub
		Session session=entitymgr.unwrap(Session.class);	
		Query<Student> query=session.createQuery("from Student",Student.class);
		List<Student> students=query.getResultList();
		return students;	
		}

	@Override
	public Student displayBasedOnId(int id) {
		// TODO Auto-generated method stub
		Session session=entitymgr.unwrap(Session.class);
		Student student=session.find(Student.class,id);
		return student;
	}

	@Override
	public void insertStudent(Student stu) {
		// TODO Auto-generated method stub
		Session session=entitymgr.unwrap(Session.class);
		session.saveOrUpdate(stu);
		
	}

	@Override
	public void updateStudent(Student stu) {
		// TODO Auto-generated method stub
		Session session=entitymgr.unwrap(Session.class);
		session.saveOrUpdate(stu);	
		
	}

	@Override
	public void deleteStudent(int id) {
		// TODO Auto-generated method stub
		Session session = entitymgr.unwrap(Session.class);
		Student student=session.find(Student.class,id);
		session.remove(student);
		
	}

	@Override
	public List<Student> displayBasedOnName(String course) {
		// TODO Auto-generated method stub
		Session session=entitymgr.unwrap(Session.class);	
		Query<Student> query=session.createQuery("from Student where course=:course",Student.class);
		query.setParameter("course", course);
		List<Student> students=query.getResultList();
		return students;
	}

}
