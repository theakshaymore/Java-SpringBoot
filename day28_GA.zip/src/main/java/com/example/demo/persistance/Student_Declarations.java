package com.example.demo.persistance;

import java.util.List;

import com.example.demo.entity.Student;

public interface Student_Declarations 
{

	List<Student> displayAll();

	Student displayBasedOnId(int id);

	void insertStudent(Student stu);

	void updateStudent(Student stu);

	void deleteStudent(int id);

	List<Student> displayBasedOnName(String course);

}
