package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Student;

public interface Service_declarations {

	List<Student> displayAllData();

	Student displayById(int id);

	void insertStudent(Student stu);

	void updateStudentDetails(Student stu);
	
	void deleteStudentDetails(int id);
	
	List<Student> displayByName(String course);

}
