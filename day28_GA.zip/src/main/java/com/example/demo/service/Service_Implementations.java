package com.example.demo.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.*;
import com.example.demo.persistance.Student_Implementations;

@Service
public class Service_Implementations implements Service_declarations
{

	private Student_Implementations stuimp;
	
	@Autowired
	public Service_Implementations(Student_Implementations stuimp) {
		super();
		this.stuimp = stuimp;
	}

	@Override
	@Transactional
	public List<Student> displayAllData() 
	{
		return stuimp.displayAll();
	}

	@Override
	@Transactional
	public Student displayById(int id) 
	{
		return stuimp.displayBasedOnId(id);
	}

	@Override
	@Transactional
	public void insertStudent(Student stu) 
	{
		stuimp.insertStudent(stu);	
	}

	@Override
	@Transactional
	public void updateStudentDetails(Student stu) 
	{
		stuimp.updateStudent(stu);
	}

	@Override
	@Transactional
	public void deleteStudentDetails(int id) 
	{
		stuimp.deleteStudent(id);	
	}

	@Override
	@Transactional
	public List<Student> displayByName(String course) 
	{
		return stuimp.displayBasedOnName(course);
	}

}
