package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;
import com.example.demo.service.Service_Implementations;

@RestController
@RequestMapping("students")
public class Student_Controller 
{
	private Service_Implementations serimp;

	@Autowired
	public Student_Controller(Service_Implementations serimp) {
		this.serimp = serimp;
	}
		@GetMapping("list")    //localhost:8080/students/list
		public List<Student> getAllStudents()
		{
			List<Student> Students=serimp.displayAllData();
			return Students;
		}
		
		@GetMapping("list/{StudentId}")    //localhost:8080/Students/list/{id}
		public Student getStudent(@PathVariable("StudentId") int id)
		{
			Student stu=serimp.displayById(id);
			if(stu==null)
			{
				throw new RuntimeException("Student not found with the given id");
			}
		return stu;
		}
		@PostMapping("list") //localhost:8080/Students/list
		public void insertionStudent(@RequestBody Student emp)
		{
			emp.setId(0);
			serimp.insertStudent(emp);
		}
		@PutMapping("list") //localhost:8080/Students/list
		public void updationStudent(@RequestBody Student emp)
		{
			serimp.insertStudent(emp);
		}
		@DeleteMapping("list/{id}")
		public void deletionStudent(@PathVariable("id") int id)
		{
			//Student.setId(0);
			serimp.deleteStudentDetails(id);
		}
		
		@GetMapping("list1/{Course}")
		public List<Student> getStudentByName(@PathVariable("Course") String course)
		{
			List<Student> stu = serimp.displayByName(course);
			return stu;
			
		}
}
