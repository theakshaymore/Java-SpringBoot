package com.example.demo.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity   //regarding entity details
@Table(name="Student") //table name
public class Student 
{
	@Id                 //tells regarding pk
	@GeneratedValue(strategy = GenerationType.IDENTITY) //auto_increment
	@Column(name="id")   //tells regarding column name
	private int id;
	@Column(name="name")
	private String name;
	@Column(name="course")
	private String course;
	@Column(name="marks")
	private int marks;
	@Column(name="DOB")
	private String DOB;
	
	public Student() 
	{
		
	}
	
	public Student(int id, String name, String course, int marks, String dOB) {
		this.id = id;
		this.name = name;
		this.course = course;
		this.marks = marks;
		DOB = dOB;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", course=" + course + ", marks=" + marks + ", DOB=" + DOB
				+ "]";
	}
	
}
